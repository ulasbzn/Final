
import { useState } from "react";
import QuestionCard from "./components/QuestionCard";
import ResultsScreen from "./components/ResultsScreen";
import { QUESTIONS } from "./questions";

function App() {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);

  const handleAnswerClick = (selectedOption) => {
    const currentQuestion = QUESTIONS[currentQuestionIndex];

    if (selectedOption === currentQuestion.correctAnswer) {
      setScore(score + 1);
    }

    setCurrentQuestionIndex(currentQuestionIndex + 1);
  };

  const restartQuiz = () => {
    setCurrentQuestionIndex(0);
    setScore(0);
  };

  const quizFinished = currentQuestionIndex >= QUESTIONS.length;

  return (
    <div style={styles.container}>
      <h1>QuickQuiz</h1>

      {quizFinished ? (
        <ResultsScreen
          score={score}
          totalQuestions={QUESTIONS.length}
          onRestart={restartQuiz}
        />
      ) : (
        <QuestionCard
          question={QUESTIONS[currentQuestionIndex]}
          onAnswerClick={handleAnswerClick}
        />
      )}
    </div>
  );
}

const styles = {
  container: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    flexDirection: "column",
    gap: "20px",
    justifyContent: "center",
    backgroundColor: "#f5f5f5",
  },
};

export default App;
