
export const QUESTIONS = [
  {
    id: 1,
    question: "What is the building block of a React app?",
    options: ["Component", "Prop", "State", "Hook"],
    correctAnswer: "Component",
  },
  {
    id: 2,
    question: "How do you pass data from parent to child?",
    options: ["State", "Props", "JSX", "Function"],
    correctAnswer: "Props",
  },
  {
    id: 3,
    question: "Which hook is used for state?",
    options: ["useFetch", "useState", "useClass", "useMap"],
    correctAnswer: "useState",
  },
  {
    id: 4,
    question: "Which syntax is used to write UI elements in React?",
    options: ["XML", "JSX", "HTML", "TPL"],
    correctAnswer: "JSX",
  },
  {
    id: 5,
    question: "Which of the following is NOT a React concept?",
    options: ["Component", "State", "Servlet", "Props"],
    correctAnswer: "Servlet",
  },
];
