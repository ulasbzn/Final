
function ResultsScreen({ score, totalQuestions, onRestart }) {
  return (
    <div style={styles.card}>
      <h2>Quiz Finished!</h2>
      <p>You scored <strong>{score}</strong> out of {totalQuestions}</p>

      <button onClick={onRestart} style={styles.restartBtn}>
        Restart Quiz
      </button>
    </div>
  );
}

const styles = {
  card: {
    padding: "20px",
    borderRadius: "10px",
    background: "white",
    boxShadow: "0 0 10px rgba(0,0,0,0.2)",
    width: "400px",
    textAlign: "center",
  },
  restartBtn: {
    marginTop: "20px",
    padding: "10px 20px",
    fontSize: "18px",
    borderRadius: "8px",
    cursor: "pointer",
  },
};

export default ResultsScreen;
