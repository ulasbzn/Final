
function QuestionCard({ question, onAnswerClick }) {
  return (
    <div style={styles.card}>
      <h2>{question.question}</h2>
      <div style={styles.optionsContainer}>
        {question.options.map((option, index) => (
          <button
            key={index}
            style={styles.optionBtn}
            onClick={() => onAnswerClick(option)}
          >
            {option}
          </button>
        ))}
      </div>
    </div>
  );
}

const styles = {
  card: {
    padding: "20px",
    borderRadius: "10px",
    background: "white",
    boxShadow: "0 0 10px rgba(0,0,0,0.2)",
    width: "400px",
    textAlign: "center",
  },
  optionsContainer: {
    marginTop: "20px",
    display: "flex",
    flexDirection: "column",
    gap: "10px",
  },
  optionBtn: {
    padding: "10px",
    fontSize: "16px",
    borderRadius: "8px",
    cursor: "pointer",
  },
};

export default QuestionCard;
